package com.escudo.app

import android.content.Context

class Blocklist(context: Context) {
    private val domains = HashSet<String>()
    private val keywords = ArrayList<String>()

    init {
        load(context, "blocklist_domains.txt") { domains.add(it) }
        load(context, "blocklist_keywords.txt") { keywords.add(it) }
    }

    private fun load(context: Context, file: String, add: (String) -> Unit) {
        context.assets.open(file).bufferedReader().useLines { lines ->
            lines.map { it.trim().lowercase() }
                .filter { it.isNotEmpty() && !it.startsWith("#") }
                .forEach(add)
        }
    }

    fun isBlocked(host: String): Boolean {
        val h = host.lowercase().trimEnd('.')
        // Dominio exacto o cualquier subdominio de uno bloqueado
        var rest = h
        while (true) {
            if (rest in domains) return true
            val dot = rest.indexOf('.')
            if (dot < 0) break
            rest = rest.substring(dot + 1)
        }
        return keywords.any { h.contains(it) }
    }
}
