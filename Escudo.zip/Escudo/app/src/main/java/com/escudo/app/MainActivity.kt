package com.escudo.app

import android.app.Activity
import android.app.AlertDialog
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var root: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(48, 48, 48, 48)
        }
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    private fun render() {
        root.removeAllViews()
        if (!PasswordStore.hasPassword(this)) renderSetup() else renderMain()
    }

    // ---------- Pantalla 1: elegir contraseña ----------
    private fun renderSetup() {
        root.addView(text("Elige una contraseña (mínimo 6 caracteres).\nLa necesitarás para desactivar o desinstalar Escudo. Guárdala bien."))
        val p1 = pwField("Contraseña")
        val p2 = pwField("Repite la contraseña")
        root.addView(p1); root.addView(p2)
        root.addView(button("Guardar contraseña") {
            val a = p1.text.toString()
            when {
                a.length < 6 -> toast("Mínimo 6 caracteres")
                a != p2.text.toString() -> toast("No coinciden")
                else -> { PasswordStore.set(this, a); render() }
            }
        })
    }

    // ---------- Pantalla 2: panel ----------
    private fun renderMain() {
        val dpm = getSystemService(DEVICE_POLICY_SERVICE) as DevicePolicyManager
        val admin = ComponentName(this, AdminReceiver::class.java)
        val adminOn = dpm.isAdminActive(admin)

        root.addView(text(
            "Filtro: " + (if (FilterVpnService.active) "ACTIVO" else "apagado") +
            "\nBloqueo de desinstalación: " + (if (adminOn) "ACTIVO" else "apagado") +
            "\nGuardián de ajustes: " + (if (GuardService.connected) "ACTIVO" else "apagado")
        ))

        root.addView(button("1. Activar filtro") { activateFilter() })
        root.addView(button("2. Activar bloqueo de desinstalación") {
            startActivity(Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
                .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, admin)
                .putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                    "Evita que Escudo se desinstale sin la contraseña."))
        })
        root.addView(button("3. Activar guardián de ajustes") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            toast("Busca \"Escudo guardián\" y actívalo")
        })
        root.addView(button("Desactivar filtro (pide contraseña)") {
            askPassword {
                startService(Intent(this, FilterVpnService::class.java)
                    .setAction(FilterVpnService.ACTION_STOP))
                toast("Filtro desactivado")
                root.postDelayed({ render() }, 400)
            }
        })
        root.addView(button("Desbloquear ajustes 5 min (pide contraseña)") {
            askPassword {
                PasswordStore.unlock(this)
                toast("Ajustes desbloqueados 5 minutos")
            }
        })
    }

    // ---------- Filtro VPN ----------
    private fun activateFilter() {
        val intent = VpnService.prepare(this)
        if (intent != null) startActivityForResult(intent, 1) else startFilter()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1 && resultCode == RESULT_OK) startFilter()
    }

    private fun startFilter() {
        startService(Intent(this, FilterVpnService::class.java))
        root.postDelayed({ render() }, 400)
    }

    // ---------- Utilidades de UI ----------
    private fun askPassword(onOk: () -> Unit) {
        val input = pwField("Contraseña")
        AlertDialog.Builder(this)
            .setTitle("Introduce la contraseña")
            .setView(input)
            .setPositiveButton("OK") { _, _ ->
                if (PasswordStore.verify(this, input.text.toString())) onOk()
                else toast("Contraseña incorrecta")
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun text(s: String) = TextView(this).apply {
        text = s; textSize = 16f; gravity = Gravity.CENTER; setPadding(0, 0, 0, 32)
    }

    private fun pwField(h: String) = EditText(this).apply {
        hint = h
        inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
    }

    private fun button(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label; isAllCaps = false; setOnClickListener { onClick() }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
