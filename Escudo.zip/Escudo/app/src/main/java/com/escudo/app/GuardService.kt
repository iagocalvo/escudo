package com.escudo.app

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Si estás en Ajustes / Seguridad / instalador y la pantalla menciona "Escudo"
 * (info de la app, desinstalar, administradores, VPN, accesibilidad), te manda
 * al inicio, salvo que hayas desbloqueado con la contraseña en los últimos 5 min.
 */
class GuardService : AccessibilityService() {

    companion object {
        @Volatile var connected = false
    }

    override fun onServiceConnected() {
        connected = true
    }

    override fun onUnbind(intent: Intent?): Boolean {
        connected = false
        return super.onUnbind(intent)
    }

    override fun onInterrupt() {}

    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        if (PasswordStore.isUnlocked(this)) return
        val root = rootInActiveWindow ?: return
        if (mentions(root, 0)) performGlobalAction(GLOBAL_ACTION_HOME)
    }

    private fun mentions(n: AccessibilityNodeInfo?, depth: Int): Boolean {
        if (n == null || depth > 30) return false
        val t = (n.text?.toString() ?: "") + " " + (n.contentDescription?.toString() ?: "")
        if (t.contains("escudo", ignoreCase = true)) return true
        for (i in 0 until n.childCount) if (mentions(n.getChild(i), depth + 1)) return true
        return false
    }
}
