package com.escudo.app

object Dns {
    /** Devuelve (nombre, offset donde acaba la pregunta) o null si no se puede leer. */
    private fun parse(q: ByteArray): Pair<String, Int>? {
        if (q.size < 17) return null
        var i = 12
        val labels = ArrayList<String>()
        while (i < q.size) {
            val len = q[i].toInt() and 0xFF
            if (len == 0) { i++; break }
            if (len and 0xC0 != 0 || i + 1 + len > q.size) return null
            labels.add(String(q, i + 1, len, Charsets.US_ASCII))
            i += 1 + len
        }
        val end = i + 4 // QTYPE + QCLASS
        if (end > q.size) return null
        return Pair(labels.joinToString(".").lowercase(), end)
    }

    fun queryName(q: ByteArray): String? = parse(q)?.first

    /** Respuesta NXDOMAIN: el dominio "no existe". */
    fun nxdomain(q: ByteArray): ByteArray? {
        val end = parse(q)?.second ?: return null
        val r = q.copyOf(end)
        r[2] = 0x81.toByte() // QR=1, RD=1
        r[3] = 0x83.toByte() // RA=1, RCODE=3 (NXDOMAIN)
        for (k in 6..11) r[k] = 0 // sin respuestas ni extras
        return r
    }
}
