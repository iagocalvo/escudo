package com.escudo.app

import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.util.concurrent.Executors

/**
 * VPN local que SOLO captura las consultas DNS (la ruta es una única IP falsa).
 * Los dominios bloqueados reciben NXDOMAIN; el resto se reenvía a un DNS
 * familiar (CleanBrowsing) que ya bloquea contenido adulto y fuerza SafeSearch.
 * El resto del tráfico no pasa por la VPN, así que no afecta a la velocidad.
 */
class FilterVpnService : VpnService() {

    companion object {
        const val ACTION_STOP = "com.escudo.app.STOP"
        @Volatile var active = false

        private const val FAKE_DNS = "10.111.222.2"
        private const val UPSTREAM_DNS = "185.228.168.168" // CleanBrowsing Family
    }

    private var tun: ParcelFileDescriptor? = null
    private var worker: Thread? = null
    private val pool = Executors.newFixedThreadPool(8)
    private lateinit var blocklist: Blocklist

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopFilter()
            return START_NOT_STICKY
        }
        if (!active) startFilter()
        return START_STICKY
    }

    private fun startFilter() {
        blocklist = Blocklist(this)
        tun = Builder()
            .setSession("Escudo")
            .addAddress("10.111.222.1", 32)
            .addDnsServer(FAKE_DNS)
            .addRoute(FAKE_DNS, 32)
            .setBlocking(true)
            .establish() ?: return
        active = true
        worker = Thread { loop() }.also { it.start() }
    }

    private fun stopFilter() {
        active = false
        try { tun?.close() } catch (_: Exception) {}
        tun = null
        stopSelf()
    }

    override fun onDestroy() {
        stopFilter()
        pool.shutdownNow()
        super.onDestroy()
    }

    override fun onRevoke() {
        stopFilter()
    }

    private fun loop() {
        val fd = tun?.fileDescriptor ?: return
        val input = FileInputStream(fd)
        val output = FileOutputStream(fd)
        val buf = ByteArray(32767)
        try {
            while (active) {
                val n = input.read(buf)
                if (n <= 0) continue
                val pkt = buf.copyOf(n)
                pool.execute { handle(pkt, output) }
            }
        } catch (_: Exception) {
        } finally {
            active = false
        }
    }

    private fun handle(pkt: ByteArray, output: FileOutputStream) {
        try {
            if ((pkt[0].toInt() shr 4) != 4) return            // solo IPv4
            val ihl = (pkt[0].toInt() and 0x0F) * 4
            if (pkt[9].toInt() != 17) return                   // solo UDP
            val dstPort = u16(pkt, ihl + 2)
            if (dstPort != 53) return
            val udpLen = u16(pkt, ihl + 4)
            val query = pkt.copyOfRange(ihl + 8, ihl + udpLen)

            val name = Dns.queryName(query)
            val reply = if (name != null && blocklist.isBlocked(name)) {
                Dns.nxdomain(query)
            } else {
                forward(query)
            } ?: return

            val resp = buildResponse(pkt, ihl, reply)
            synchronized(output) { output.write(resp) }
        } catch (_: Exception) {
        }
    }

    private fun forward(query: ByteArray): ByteArray? {
        val socket = DatagramSocket()
        return try {
            protect(socket) // que esta consulta salga por la red real, no por la VPN
            socket.soTimeout = 4000
            val addr = InetAddress.getByName(UPSTREAM_DNS)
            socket.send(DatagramPacket(query, query.size, addr, 53))
            val rb = ByteArray(4096)
            val rp = DatagramPacket(rb, rb.size)
            socket.receive(rp)
            rb.copyOf(rp.length)
        } catch (_: Exception) {
            null
        } finally {
            socket.close()
        }
    }

    private fun buildResponse(req: ByteArray, ihl: Int, payload: ByteArray): ByteArray {
        val total = ihl + 8 + payload.size
        val out = ByteArray(total)
        System.arraycopy(req, 0, out, 0, ihl)
        // Intercambiar IP origen/destino
        System.arraycopy(req, 12, out, 16, 4)
        System.arraycopy(req, 16, out, 12, 4)
        out[2] = (total shr 8).toByte(); out[3] = total.toByte()
        out[8] = 64
        out[10] = 0; out[11] = 0
        val c = checksum(out, ihl)
        out[10] = (c shr 8).toByte(); out[11] = c.toByte()
        // UDP: intercambiar puertos
        System.arraycopy(req, ihl + 2, out, ihl, 2)
        System.arraycopy(req, ihl, out, ihl + 2, 2)
        val udpLen = 8 + payload.size
        out[ihl + 4] = (udpLen shr 8).toByte(); out[ihl + 5] = udpLen.toByte()
        out[ihl + 6] = 0; out[ihl + 7] = 0 // checksum UDP opcional en IPv4
        System.arraycopy(payload, 0, out, ihl + 8, payload.size)
        return out
    }

    private fun u16(b: ByteArray, i: Int) =
        ((b[i].toInt() and 0xFF) shl 8) or (b[i + 1].toInt() and 0xFF)

    private fun checksum(b: ByteArray, len: Int): Int {
        var sum = 0
        var i = 0
        while (i < len) {
            sum += u16(b, i)
            i += 2
        }
        while ((sum shr 16) != 0) sum = (sum and 0xFFFF) + (sum shr 16)
        return sum.inv() and 0xFFFF
    }
}
