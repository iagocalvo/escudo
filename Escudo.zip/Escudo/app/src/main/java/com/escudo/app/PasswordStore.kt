package com.escudo.app

import android.content.Context
import android.util.Base64
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/** Guarda solo un hash de la contraseña (PBKDF2), nunca la contraseña en claro. */
object PasswordStore {
    private const val PREFS = "escudo_prefs"
    private const val ITER = 120_000
    private const val UNLOCK_MS = 5 * 60 * 1000L

    private fun prefs(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun hasPassword(c: Context) = prefs(c).contains("hash")

    private fun hash(pw: String, salt: ByteArray): ByteArray =
        SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
            .generateSecret(PBEKeySpec(pw.toCharArray(), salt, ITER, 256)).encoded

    fun set(c: Context, pw: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        prefs(c).edit()
            .putString("salt", Base64.encodeToString(salt, Base64.NO_WRAP))
            .putString("hash", Base64.encodeToString(hash(pw, salt), Base64.NO_WRAP))
            .apply()
    }

    fun verify(c: Context, pw: String): Boolean {
        val salt = Base64.decode(prefs(c).getString("salt", "") ?: "", Base64.NO_WRAP)
        val stored = Base64.decode(prefs(c).getString("hash", "") ?: "", Base64.NO_WRAP)
        return MessageDigest.isEqual(stored, hash(pw, salt))
    }

    /** Tras acertar la contraseña, los ajustes protegidos se abren durante 5 minutos. */
    fun unlock(c: Context) {
        prefs(c).edit().putLong("unlocked_until", System.currentTimeMillis() + UNLOCK_MS).apply()
    }

    fun isUnlocked(c: Context) =
        System.currentTimeMillis() < prefs(c).getLong("unlocked_until", 0L)
}
